# Computational labs ms-09, ms-10, ms-11

Extract the whole archive and preserve notebooks/, simulations/, data/, scripts/.
Use Python 3.12, install requirements-labs.txt and launch JupyterLab from this
folder. Restart and run 09-dispersion.ipynb, 10-coupling.ipynb, then
11-inverse-design.ipynb. Figures and results regenerate from the exposed inputs.
One BLAS thread is recommended for these small matrices. CPU only.

Install requirements-validation.txt to run the optional grcwa comparison.
Without it, the inverse notebook records that check as unexecuted. The published
reference includes it. Run python scripts/validate_design_studies.py --grcwa
after the notebooks. The validator checks the fixed published configuration;
edited physical parameters require new convergence and acceptance criteria.

Browser labs are available online at:
https://metasurface-ir.github.io/metasurfaces-book/dispersion-lab/
https://metasurface-ir.github.io/metasurfaces-book/coupling-lab/
https://metasurface-ir.github.io/metasurfaces-book/inverse-design-lab/

Restricted 1D lossless TE periodic ridges. Real constant indices; no measured
material dispersion, finite devices, FEM/FDTD or experiment. All plots and
geometry views are original. Retain assumptions, references and provenance.
