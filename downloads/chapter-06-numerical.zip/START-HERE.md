# Chapter 6 numerical methods

Extract the complete ZIP and preserve its folders. With Python 3.12 create a
virtual environment, install requirements-labs.txt, and launch JupyterLab.
Restart and run notebooks/06-numerical-methods.ipynb. It imports the simulations/
modules and reads the explicitly labeled fixed RCWA data. Modified slab
parameters generate a separate data/chapter-06/notebook-experiment.json.

Run python scripts/validate_chapter06.py from the extracted root for the fixed
benchmark audit. It writes reference data and a validation report. A successful
reference audit does not certify a newly modified physical configuration.
The browser explorer opens offline from interactives/numerical-explorer.html.
It selects saved data, not a live solver.

This is a 1D lossless equal-exterior FDFD slab with a discrete radiation boundary.
It is not FDTD, FEM, PML, finite-device or experimental validation. The separate
RCWA companion is a restricted periodic TE calculation. Keep its model labels,
reference planes, conventions, scope and source provenance when sharing results.
