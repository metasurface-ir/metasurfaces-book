# Chapter 3 source bundle

Extract the entire ZIP. Use Python 3.12. From this folder:

    python -m venv .venv
    .venv/Scripts/python -m pip install -r requirements-labs.txt
    .venv/Scripts/python -m jupyterlab notebooks

On macOS/Linux replace .venv/Scripts/python with .venv/bin/python.
Open 03-unit-cell-library.ipynb; restart its Python kernel and run all cells.
The notebook finds simulations/unit_cell_te.py from this folder structure.
It regenerates response-library.json and .csv in data/chapter-03/.
The saved validation.json describes the published reference, not your edited run.
After editing, rerun scripts/validate_chapter03.py. For its optional --grcwa
comparison also install requirements-validation.txt. See the data README.
