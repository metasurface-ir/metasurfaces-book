# Chapter 2: waves, interfaces, and sheets

Extract the complete ZIP and preserve notebooks/, simulations/, scripts/, data/,
and assets/. Browser labs are hosted on the book website.

For Python, use Python 3.12 in a virtual environment. Install requirements-labs.txt
and open notebooks/02-waves-and-interfaces.ipynb in JupyterLab. Restart its kernel
and run all cells. NumPy and Matplotlib perform these calculations on a CPU;
the shared requirements also support later course notebooks. No commercial
solver, GPU, or downloaded dataset is required after installing the environment.
Run python scripts/validate_chapter02.py from this extracted root for the audit.

The calculations are exact restricted planar interface/film/electric-sheet and
Jones models. They do not discretize a patterned metasurface or validate a
fabricated device. Preserve the time/basis/reference-plane conventions and model
limitations when modifying results. The film and electric sheet are distinct
models, and arbitrary film coefficients cannot be retrieved as a zero-thickness
electric shunt without validating the model and phase planes first.
