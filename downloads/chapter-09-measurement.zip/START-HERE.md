# Chapter 9: materials, fabrication and measurement

Extract the whole ZIP and preserve folders. Use Python 3.12 in a virtual
environment and install requirements-labs.txt, then open JupyterLab.
Restart and run notebooks/09-fabrication-measurement.ipynb.
Run python scripts/validate_chapter09.py separately from the extracted root.
The audit evaluates declared baseline cases, not every parameter you may change.
Preserve reference.json and synthetic-sweep.csv before editing: the notebook writes them.

ALL observations are synthetic. The material oscillator is illustrative.
The resonator has assigned rates and local geometric scaling, not a solved patch.
Ideal short/load/open standards demonstrate a one-port error box, not free-space
horn calibration. The CSV is noiseless; the notebook separately propagates
characterization, reading and placement uncertainty in Monte Carlo trials.
Browser labs open on the website; this archive contains no browser HTML.
