# Chapter 8: communication links

Extract the complete ZIP and preserve folders. Use Python 3.12, install
requirements-labs.txt in a virtual environment, and launch JupyterLab.
Restart and run notebooks/08-communication-links.ipynb.
Run python scripts/validate_chapter08.py from the extracted root separately.
The audit evaluates declared baseline cases, not every parameter you may change.
Preserve reference.json before editing: the notebook writes that file.

The model is a scalar projected-aperture approximation with assigned efficiency,
ideal phase states, a single polarization and free-space paths. It is not a
full-wave patterned surface, calibrated hardware, or measured wireless link.
Browser labs open on the book website; no browser HTML is included here.
