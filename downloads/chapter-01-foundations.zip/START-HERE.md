# Chapter 1 source bundle

Extract the complete ZIP. Use Python 3.12 and install requirements-labs.txt in
a virtual environment, then launch JupyterLab. Open the notebook in notebooks/
and restart/run all cells. Preserve simulations/ and data/ alongside notebooks/.
The model needs NumPy/Matplotlib only; the shared requirements also support the
later course labs. It runs without a commercial solver, GPU, or network dataset.
Run python scripts/validate_chapter01.py from this folder for analytical checks.

This is a lossless equal-impedance specular sheet model, not a full-wave device.
Preserve that model label and its assumptions when sharing or editing results.
