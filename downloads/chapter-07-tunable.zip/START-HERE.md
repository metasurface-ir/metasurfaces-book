# Chapter 7: tuning, coding and feedback

Extract the complete ZIP and keep its folders. Use Python 3.12, create a virtual
environment, install requirements-labs.txt, and launch JupyterLab. Restart and
run notebooks/07-tunable-metasurfaces.ipynb from the extracted folder structure.
Run python scripts/validate_chapter07.py for the fixed reference audit.
The audit checks its declared reference cases, not every parameter you may edit.
Preserve the reference data before rerunning: the notebook writes reference.json.

The model is an assigned effective impedance, prescribed scalar array, synthetic
noiseless feedback and slow modulation envelope. The drawing is schematic; no
physical patch, diode or fabricated device has been simulated or measured.
Array intensity and envelope harmonic weights are not device efficiencies.
The browser lab is available on the book website.
